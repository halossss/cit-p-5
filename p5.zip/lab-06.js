class Book {
    constructor(title, author, pubDate, isbn) {
      this.title = title;
      this.author = author;
      this.pubDate = pubDate;
      this.isbn = isbn;
    }
  }

class Library {
    constructor(name) {
      this._name = name;
      this._books = [];
    }
    get books() {
      // Return copy of books
      return JSON.parse(JSON.stringify(this._books));
    }
    get count() {
      return this._books.length;
    }
    addBook(book = {}) {
      const { title = "", author = "", pubDate = "", isbn = ""} = book;
      if (title.length > 0 && author.length > 0 && isbn.length > 0) {
        const newBook = { title, author, pubDate, isbn };
        this._books.push(newBook);
      }
    }
    listBooks() {
      for (const book of this._books) {
        const {title, author, pubDate, isbn} = book;
        console.log(`Title: ${title}, Author: ${author}, PubDate: ${pubDate}, ISBN: ${isbn}`)
      }
    }
    deleteBook(isbn) {
        this._books = this._books.filter(book => book.isbn !== isbn);
    }
}

  // Create library object
const library = new Library("New York Times Best Seller List");

// Create a book
const atomicHabits = new Book("Atomic Habits", "James Clear", "10/16/2018", "0735211292"); //added isbn

//create 2 more books
const NEUROMANCER = new Book("NEUROMANCER", "William Gibson", "7/1/1984", "0441569595")
const DARKMATTER = new Book("DARK MATTER", "Blake Crouch", "7/26/2016", "1101904220")

// Add book to library and output library count and books
library.addBook(atomicHabits);
library.addBook(NEUROMANCER);
library.addBook(DARKMATTER);
console.log(`Book count: ${library.count}`);
library.listBooks();

library.deleteBook("0735211292");
console.log(`Book count: ${library.count}`);
library.listBooks();
