const MonsterGame = require("./p5-monster-game.js");

module.exports = class Monster {
  constructor(monsterName = "Unknown", minimumLife = 0, currentLife = 100) {
      this.monsterName = monsterName,
      this.minimumLife = minimumLife,
      this.currentLife = currentLife,
      this.isAlive = this.currentLife >= minimumLife;
  }

updateLife(lifeChangeAmount) {
  this.currentLife = Math.max(0, this.currentLife + lifeChangeAmount);
  this.isAlive = this.currentLife > this.minimumLife;
}

  randomLifeDrain(minimumLifeDrain, maximumLifeDrain) {
    const lifeDrain = this.getRandomInteger(minimumLifeDrain, maximumLifeDrain + 1);
    this.updateLife(-lifeDrain);
    console.log(`Monster ${this.monsterName} lost ${lifeDrain} life points.`);
  }

  getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
  }
}
